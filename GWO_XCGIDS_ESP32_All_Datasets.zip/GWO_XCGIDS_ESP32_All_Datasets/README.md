# GWO-XCGIDS ESP32 deployment for all three datasets

This package prepares separate INT8 TensorFlow Lite models and separate Arduino IDE sketches for:

- WUSTL-EHMS-2020 (`wustl_ehms_2020`)
- MedSec-25 (`medsec_25`)
- IoMT-IND2026 (`iomt_ind_2026`)

## Required trained models

The conversion process expects these files produced by the training pipeline:

- `esp32/models/wustl_ehms_2020/cnn_gru_best.keras`
- `esp32/models/medsec_25/cnn_gru_best.keras`
- `esp32/models/iomt_ind_2026/cnn_gru_best.keras`

It also expects the preprocessed datasets and metadata produced by `data_preprocessing.py`. It generates sequences through the same `load_sequence_data()` function used by the training script, so the representative data uses the pipeline's current sequence-generation logic.

## Convert all three

Run from the project root:

```bash
python esp32_deployment/models/export_all_datasets.py
```

Convert one dataset only:

```bash
python esp32_deployment/models/export_all_datasets.py --datasets wustl_ehms_2020
python esp32_deployment/models/export_all_datasets.py --datasets medsec_25
python esp32_deployment/models/export_all_datasets.py --datasets iomt_ind_2026
```

The script writes, for each dataset, `model_int8.tflite`, `model_data.h`, and `deployment_report.json` under `esp32/deployment/<dataset_key>/`.

## Arduino IDE

Each dataset has a separate sketch folder under `firmware/`. For the dataset you want to deploy, copy its generated `model_data.h` into that sketch folder, open its `.ino` file in Arduino IDE, install a compatible TensorFlow Lite Micro library, select the ESP32-WROOM-32E board, and compile.

Only one dataset model is loaded by a given firmware build. To switch datasets, use the corresponding sketch and header.

## Input requirements

The firmware accepts one comma-separated line of floating-point values over Serial at 115200 baud. The number of values must equal the model input tensor element count. For a sequence model this is typically sequence_length multiplied by selected feature count. Values must already be preprocessed exactly as in training, including feature ordering, imputation, encoding, feature selection, and scaling.

This firmware is an inference interface, not a complete live IoMT acquisition pipeline. It does not read sensors, calculate GWO features, or perform preprocessing.

## Compatibility and hardware validation

Full INT8 conversion may fail if a model operation cannot be quantized. Even if conversion succeeds, TensorFlow Lite Micro on the selected ESP32 library must support every operator in the model. GRU operator support is a key compatibility risk. Review the TensorFlow Lite operator analyzer output and compile against the exact library version.

The 160 KiB tensor arena is only an initial allocation. Measure actual RAM and flash use on the board. Validate desktop-versus-device prediction agreement, inference latency, and peak memory before reporting deployment results. Do not claim successful ESP32 deployment until the firmware compiles and inference is validated on the physical board.
