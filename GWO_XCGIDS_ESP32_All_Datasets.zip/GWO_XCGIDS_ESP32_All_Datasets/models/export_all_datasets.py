import argparse
import json
from pathlib import Path

import numpy as np
import tensorflow as tf

try:
    from config import DATASETS, PROJECT_ROOT, SEQUENCE_LENGTH
    from train_model import load_sequence_data, MODEL_OUTPUT_DIR
except ImportError:
    from src.config import DATASETS, PROJECT_ROOT, SEQUENCE_LENGTH
    from src.train_model import load_sequence_data, MODEL_OUTPUT_DIR


OUTPUT_ROOT = PROJECT_ROOT / "esp32"
DEPLOYMENT_ROOT = OUTPUT_ROOT / "deployment"


def convert_one(dataset_key, sample_limit):
    if dataset_key not in DATASETS:
        raise KeyError(f"Unknown dataset key: {dataset_key}")

    model_path = MODEL_OUTPUT_DIR / dataset_key / "cnn_gru_best.keras"
    if not model_path.is_file():
        raise FileNotFoundError(
            f"Missing trained model for {dataset_key}: {model_path}. "
            "Train this dataset first."
        )

    sequences, metadata = load_sequence_data(
        dataset_key,
        sequence_length=SEQUENCE_LENGTH,
    )
    representative = np.asarray(sequences["X_train"], dtype=np.float32)
    if representative.ndim != 3 or len(representative) == 0:
        raise ValueError(f"Invalid training sequences for {dataset_key}.")

    representative = representative[: min(sample_limit, len(representative))]
    model = tf.keras.models.load_model(model_path, compile=False)

    if tuple(model.input_shape[1:]) != tuple(representative.shape[1:]):
        raise ValueError(
            f"Input shape mismatch for {dataset_key}: model={model.input_shape}, "
            f"data={representative.shape}."
        )

    def representative_dataset():
        for item in representative:
            yield [item[np.newaxis, ...].astype(np.float32)]

    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = representative_dataset
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8

    tflite_content = converter.convert()
    dataset_output = DEPLOYMENT_ROOT / dataset_key
    model_output = dataset_output / "model_int8.tflite"
    model_output.parent.mkdir(parents=True, exist_ok=True)
    model_output.write_bytes(tflite_content)

    interpreter = tf.lite.Interpreter(model_content=tflite_content)
    interpreter.allocate_tensors()
    input_detail = interpreter.get_input_details()[0]
    output_detail = interpreter.get_output_details()[0]

    if input_detail["dtype"] != np.int8 or output_detail["dtype"] != np.int8:
        raise RuntimeError(f"{dataset_key}: converter did not produce int8 I/O.")

    if tuple(input_detail["shape"][1:]) != tuple(representative.shape[1:]):
        raise RuntimeError(f"{dataset_key}: converted input shape changed.")

    header_path = dataset_output / "model_data.h"
    export_header(tflite_content, input_detail, output_detail, header_path)

    report = {
        "dataset_key": dataset_key,
        "dataset_name": metadata.get("dataset_name", DATASETS[dataset_key]["name"]),
        "keras_model": str(model_path),
        "tflite_model": str(model_output),
        "c_header": str(header_path),
        "model_size_bytes": len(tflite_content),
        "input_shape": input_detail["shape"].tolist(),
        "output_shape": output_detail["shape"].tolist(),
        "input_quantization": [
            float(input_detail["quantization"][0]),
            int(input_detail["quantization"][1]),
        ],
        "output_quantization": [
            float(output_detail["quantization"][0]),
            int(output_detail["quantization"][1]),
        ],
        "representative_samples": len(representative),
    }
    (dataset_output / "deployment_report.json").write_text(
        json.dumps(report, indent=4),
        encoding="utf-8",
    )
    print(json.dumps(report, indent=4))


def export_header(content, input_detail, output_detail, output_path):
    byte_lines = []
    for start in range(0, len(content), 12):
        byte_lines.append(
            "    " + ", ".join(f"0x{byte:02x}" for byte in content[start:start + 12])
        )
    array_data = ",\n".join(byte_lines)
    input_count = int(np.prod(input_detail["shape"]))
    output_count = int(np.prod(output_detail["shape"]))
    input_scale, input_zero = input_detail["quantization"]
    output_scale, output_zero = output_detail["quantization"]

    header = f"""#ifndef GWO_XCGIDS_MODEL_DATA_H
#define GWO_XCGIDS_MODEL_DATA_H

#include <stdint.h>

alignas(16) const unsigned char gwo_xcgids_model[] = {{
{array_data}
}};

const unsigned int gwo_xcgids_model_len = {len(content)};
const int gwo_xcgids_model_input_elements = {input_count};
const int gwo_xcgids_model_output_elements = {output_count};
const float gwo_xcgids_model_input_scale = {float(input_scale):.10g}f;
const int gwo_xcgids_model_input_zero_point = {int(input_zero)};
const float gwo_xcgids_model_output_scale = {float(output_scale):.10g}f;
const int gwo_xcgids_model_output_zero_point = {int(output_zero)};

#endif
"""
    output_path.write_text(header, encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--datasets",
        nargs="*",
        default=list(DATASETS.keys()),
        choices=list(DATASETS.keys()),
    )
    parser.add_argument("--samples", type=int, default=100)
    args = parser.parse_args()

    for key in args.datasets:
        convert_one(key, args.samples)


if __name__ == "__main__":
    main()
