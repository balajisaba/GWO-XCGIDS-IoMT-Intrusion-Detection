#include <Arduino.h>
#include <TensorFlowLite.h>
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/version.h"
#include "model_data.h"

constexpr int kTensorArenaSize = 160 * 1024;
alignas(16) uint8_t tensor_arena[kTensorArenaSize];

const tflite::Model* model = nullptr;
tflite::AllOpsResolver resolver;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* input_tensor = nullptr;
TfLiteTensor* output_tensor = nullptr;

bool readValues(const String& line, float* values, int expected) {
    int position = 0;
    int count = 0;
    while (position < line.length() && count < expected) {
        int comma = line.indexOf(',', position);
        String token = comma < 0 ? line.substring(position) : line.substring(position, comma);
        token.trim();
        if (token.length() == 0) return false;
        char* end = nullptr;
        values[count] = strtof(token.c_str(), &end);
        if (end == token.c_str() || *end != '\0') return false;
        count++;
        if (comma < 0) position = line.length();
        else position = comma + 1;
    }
    return count == expected && position >= line.length();
}

void setup() {
    Serial.begin(115200);
    Serial.setTimeout(1000);
    model = tflite::GetModel(gwo_xcgids_model);
    if (model->version() != TFLITE_SCHEMA_VERSION) {
        Serial.println("MODEL_SCHEMA_VERSION_MISMATCH");
        return;
    }

    static tflite::MicroInterpreter static_interpreter(
        model, resolver, tensor_arena, kTensorArenaSize
    );
    interpreter = &static_interpreter;

    if (interpreter->AllocateTensors() != kTfLiteOk) {
        Serial.println("TENSOR_ALLOCATION_FAILED");
        return;
    }

    input_tensor = interpreter->input(0);
    output_tensor = interpreter->output(0);

    if (input_tensor->type != kTfLiteInt8 || output_tensor->type != kTfLiteInt8) {
        Serial.println("MODEL_IO_MUST_BE_INT8");
        return;
    }

    if (input_tensor->bytes != gwo_xcgids_model_input_elements) {
        Serial.println("MODEL_INPUT_SIZE_MISMATCH");
        return;
    }

    Serial.println("GWO_XCGIDS_READY");
    Serial.print("INPUT_ELEMENTS=");
    Serial.println(gwo_xcgids_model_input_elements);
    Serial.println("Send exactly INPUT_ELEMENTS comma-separated normalized floats.");
}

void loop() {
    if (!interpreter || !input_tensor || !output_tensor || !Serial.available()) return;

    String line = Serial.readStringUntil('\n');
    line.trim();
    if (line.length() == 0) return;

    static float values[gwo_xcgids_model_input_elements];
    if (!readValues(line, values, gwo_xcgids_model_input_elements)) {
        Serial.println("INVALID_INPUT_LENGTH_OR_VALUE");
        return;
    }

    for (int i = 0; i < gwo_xcgids_model_input_elements; i++) {
        int32_t q = static_cast<int32_t>(round(
            values[i] / gwo_xcgids_model_input_scale
        )) + gwo_xcgids_model_input_zero_point;
        q = constrain(q, -128, 127);
        input_tensor->data.int8[i] = static_cast<int8_t>(q);
    }

    if (interpreter->Invoke() != kTfLiteOk) {
        Serial.println("INFERENCE_ERROR");
        return;
    }

    Serial.print("OUTPUT");
    for (int i = 0; i < gwo_xcgids_model_output_elements; i++) {
        float score = (
            static_cast<int32_t>(output_tensor->data.int8[i]) -
            gwo_xcgids_model_output_zero_point
        ) * gwo_xcgids_model_output_scale;
        Serial.print(',');
        Serial.print(score, 6);
    }
    Serial.println();
}
